# Shell-Scripting-Bash
Solutions to some of the Questions under the following Topics:
1. Patterns
2. Arithmetic Calculator using Command Line
3. File Contents Operations
4. Mathematical Problems
5. String Manipulations
6. Sorting
7. Recursive Function
8. File and Folder Handling
